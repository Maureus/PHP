create view QUIZ_QUESTIONS_VIEW as
SELECT q.id, q.name, q.type, q.created_at, q.updated_at, qz.name, qz.id
FROM questions q JOIN question_quiz qq
    ON q.id = qq.question_id
JOIN quizzes qz
    ON qq.quiz_id = qz.id
/

