create trigger PREDMETY_TRG
    before insert
    on PREDMETY
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

