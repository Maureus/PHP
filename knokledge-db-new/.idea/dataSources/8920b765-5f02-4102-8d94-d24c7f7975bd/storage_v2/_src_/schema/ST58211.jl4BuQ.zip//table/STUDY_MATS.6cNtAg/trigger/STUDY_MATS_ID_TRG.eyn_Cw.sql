create trigger STUDY_MATS_ID_TRG
    before insert
    on STUDY_MATS
    for each row
begin
            if :new.ID is null then
                select study_mats_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

