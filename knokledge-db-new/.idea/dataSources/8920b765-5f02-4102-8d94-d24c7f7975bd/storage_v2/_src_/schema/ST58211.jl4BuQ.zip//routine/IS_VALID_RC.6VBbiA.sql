create FUNCTION IS_VALID_RC 
(
  RC IN NUMBER  
) RETURN NUMBER AS

  i_zbytek NUMBER;
  i_mesic NUMBER;
  i_rok NUMBER;
  i_den NUMBER;
  i_datum DATE;

BEGIN

  IF LENGTH(RC) NOT BETWEEN 9 AND 10 THEN
    RETURN 0;
  END IF;

  -- rodné èíslo pøed rokem 1954
  IF LENGTH(RC) = 9 AND SUBSTR(RC,1,2) < 54 THEN
    RETURN 1;
  END IF;

  -- zbytek po dìlení 11 prvních deviti èísel
  i_zbytek := MOD(SUBSTR(RC,1,9),11);

  IF i_zbytek = 10 THEN
    i_zbytek := 0;
  END IF;

  i_rok := TO_NUMBER(SUBSTR(RC,1,2));
  i_mesic := TO_NUMBER(SUBSTR(RC,3,2));
  i_den := TO_NUMBER(SUBSTR(RC,5,2));

  IF i_rok < 54 THEN
    i_rok := i_rok + 2000;
  ELSE
    i_rok := i_rok + 1900;
  END IF;

  -- odeèítaní 20,50,70 v pøípadì ženského RC
  IF i_mesic > 70 AND i_rok > 2003 THEN
    i_mesic := i_mesic - 70;
  ELSIF i_mesic > 50 THEN
    i_mesic := i_mesic - 50;
  ELSIF i_mesic > 20 AND i_rok > 2003 THEN
    i_mesic := i_mesic - 20;
  END IF;

  -- kontrola, zda je to platné datum.
  BEGIN
    i_datum := TO_DATE(i_den || '.' || i_mesic || '.' || i_rok,'DD.MM.YYYY');
  EXCEPTION WHEN OTHERS THEN
    RETURN 0;
  END;

    -- rovná se zbytek poslední èíslici?
  IF i_zbytek = SUBSTR(RC,10,1) THEN
    RETURN 1;
  ELSE
    RETURN 0;
  END IF;

END IS_VALID_RC;
/

