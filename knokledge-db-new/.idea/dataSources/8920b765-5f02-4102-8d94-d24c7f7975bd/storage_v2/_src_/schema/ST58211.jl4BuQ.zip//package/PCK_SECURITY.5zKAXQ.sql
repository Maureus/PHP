create PACKAGE PCK_SECURITY AS
PROCEDURE edit_user(p_usr_id NUMBER,
p_usr_name VARCHAR2, p_usr_pwd VARCHAR2,
p_valid_from VARCHAR2, p_valid_till VARCHAR2,
p_result OUT CLOB);
PROCEDURE login(p_usr_name VARCHAR2, p_usr_pwd
VARCHAR2,
p_result OUT CLOB, p_usr_id OUT NUMBER);
END PCK_SECURITY;
/

