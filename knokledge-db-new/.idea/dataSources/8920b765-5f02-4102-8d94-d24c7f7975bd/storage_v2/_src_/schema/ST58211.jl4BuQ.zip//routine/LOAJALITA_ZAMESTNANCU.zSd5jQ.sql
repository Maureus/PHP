create FUNCTION loajalita_zamestnancu(p_datum DATE) RETURN VARCHAR2
AS
i_zarazeni NUMBER;
BEGIN
i_zarazeni := (SYSDATE - p_datum) / 365;
CASE
WHEN i_zarazeni >= 0 AND i_zarazeni < 5 THEN
RETURN 'Zelenáč';
WHEN i_zarazeni >= 5 AND i_zarazeni < 10 THEN
RETURN 'Zasloužilý';
WHEN i_zarazeni >= 10 THEN
RETURN 'Matador';
ELSE
RETURN 'Neznámá';
END CASE;
END loajalita_zamestnancu;
/

