create procedure insert_users(
    p_id IN users.id%TYPE DEFAULT NULL,
    p_name IN OUT users.name%TYPE,
    p_email IN OUT users.email%TYPE,
    p_password IN users.password%TYPE,
    p_created_at OUT users.created_at%TYPE,
    p_updated_at OUT users.updated_at%TYPE,
    p_id_out OUT users.id%TYPE,
    p_role_out IN OUT users.role%TYPE
) is
begin
    if p_id = NULL then
        insert into users(name, email, password, created_at, updated_at)
        values (p_name, p_email, p_password, CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6));
        COMMIT;
        select id, role, created_at, updated_at 
        into p_id_out, p_role_out, p_created_at, p_updated_at
        from users where ROWNUM = (select max(ROWNUM) from users);
    else
        update users set name = p_name, email = p_email, password = p_password,
        updated_at = CURRENT_TIMESTAMP(6) where id = p_id;
        COMMIT;
        select id, role, created_at, updated_at 
        into p_id_out, p_role_out, p_created_at, p_updated_at
        from users where ROWNUM = (select max(ROWNUM) from users);
    end if;
    EXCEPTION
    WHEN OTHERS THEN
    raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
end;
/

