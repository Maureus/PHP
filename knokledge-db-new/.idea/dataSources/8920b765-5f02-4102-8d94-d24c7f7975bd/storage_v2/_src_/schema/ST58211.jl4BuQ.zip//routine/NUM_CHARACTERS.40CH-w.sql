create FUNCTION num_characters (p_string IN VARCHAR2)
RETURN INTEGER AS
    v_num_characters INTEGER;
BEGIN
    SELECT LENGTH(p_string) INTO v_num_characters
    FROM dual;
    RETURN v_num_characters;
END;
/

