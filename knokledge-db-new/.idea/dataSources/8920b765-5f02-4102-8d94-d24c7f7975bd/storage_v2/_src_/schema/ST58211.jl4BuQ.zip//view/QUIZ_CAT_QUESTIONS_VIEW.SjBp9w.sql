create view QUIZ_CAT_QUESTIONS_VIEW as
SELECT q.id, q.name, q.type, q.created_at, q.updated_at, qz.name, qz.id
FROM questions q JOIN quizzes qz
    ON q.category_id = qz.category_id
/

