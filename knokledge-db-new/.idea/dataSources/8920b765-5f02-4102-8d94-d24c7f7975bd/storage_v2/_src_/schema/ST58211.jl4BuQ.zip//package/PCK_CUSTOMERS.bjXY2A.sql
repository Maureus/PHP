create PACKAGE PCK_CUSTOMERS AS
PROCEDURE edit_customer(p_cus_id NUMBER, p_cus_name
VARCHAR2, p_cus_surname VARCHAR2, p_cus_email VARCHAR2,
p_cus_phone VARCHAR2, p_usr_id NUMBER,
p_result OUT CLOB);
PROCEDURE edit_customer_address(p_cua_id NUMBER, p_cus_id
NUMBER, p_cua_street VARCHAR2,
p_cua_city VARCHAR2, p_cua_zip NUMBER,
p_cua_country VARCHAR2, p_cua_type NUMBER,
p_usr_id NUMBER, p_result OUT CLOB);
END PCK_CUSTOMERS;
/

