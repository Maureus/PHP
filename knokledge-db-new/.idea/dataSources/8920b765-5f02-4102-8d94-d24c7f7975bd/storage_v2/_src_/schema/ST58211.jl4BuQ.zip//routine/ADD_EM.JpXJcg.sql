create FUNCTION ADD_EM
    (a NUMBER := 1,
    b NUMBER := 2 )
    RETURN NUMBER
IS BEGIN
    RETURN (a+b);
END ADD_EM;
/

