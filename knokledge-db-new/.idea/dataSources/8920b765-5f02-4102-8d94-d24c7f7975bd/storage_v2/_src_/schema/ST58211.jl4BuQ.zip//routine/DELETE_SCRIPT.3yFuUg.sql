create procedure delete_script(p_schema varchar2)
as
begin
    dbms_output.put_line('DROP SCHEMA IF EXISTS '||p_schema||';');
end;
/

