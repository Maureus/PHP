create view USER_SUBJECTS_VIEW as
SELECT s.id, s.name, s.semester, s.year, s.short_name, s.subject_desc, s.created_at, s.updated_at, u.id
FROM subjects s JOIN subject_user us
    ON s.id = us.subject_id
JOIN users u
    ON us.user_id = u.id
/

