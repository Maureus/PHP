create trigger PERSONAL_ACCESS_TOKENS_ID_TRG
    before insert
    on PERSONAL_ACCESS_TOKENS
    for each row
begin
            if :new.ID is null then
                select personal_access_tokens_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

