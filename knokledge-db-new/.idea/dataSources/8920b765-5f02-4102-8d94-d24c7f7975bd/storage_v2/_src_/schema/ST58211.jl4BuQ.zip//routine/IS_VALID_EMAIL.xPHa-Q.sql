create FUNCTION IS_VALID_EMAIL 
(
  EMAIL IN VARCHAR2  
) RETURN NUMBER AS
  
  i_result NUMBER;

BEGIN

  SELECT 
    COUNT(*) INTO i_result 
  FROM
    dual 
  WHERE 
    REGEXP_LIKE(EMAIL,'^[a-zA-Z0-9._-]+@+[a-zA-Z0-9.-]+\.+[a-zA-Z]{2,4}$');

  RETURN i_result;

END IS_VALID_EMAIL;
/

