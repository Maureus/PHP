create view QUIZ_USER_RESULT_VIEW as
SELECT qz.id, qz.name, u.id, u.name, qur.result
FROM users u JOIN quiz_user_result qur
    ON u.id = qur.user_id
JOIN quizzes qz
    ON qur.quiz_id = qz.id
/

