create view USER_COURSES_VIEW as
SELECT c.id, c.name, c.acc_key, c.course_desc, c.created_by, c.edited_by,
c.created_at, c.updated_at, c.subject_id, u.id
FROM courses c JOIN course_user cu
    ON c.id = cu.course_id
JOIN users u
    ON cu.user_id = u.id
/

